package pkg;

import java.io.IOException;
import java.net.Socket;
import java.util.concurrent.TimeUnit;

/**
 *
 */
public class ClientThread extends Thread
{
  Socket socket;
  ClientThread pair;
  boolean running=true;

  ClientThread(Socket socket_arg)
  {
    socket=socket_arg;   
     
  }
  
  @Override
  public void run()
  {
    System.out.println("Client connected!"); 
    while(pair==null)
    {
      try
      {TimeUnit.MILLISECONDS.sleep(10);}
      catch(InterruptedException e)
      {System.out.println("NO SLEEP FOR YA!");}
    }
    
    System.out.println("Paired with other client!");
    
    try
    {
      Sender sender=new Sender(socket);
      while(running)
      {
        Object received=sender.receive();
        
        if (received instanceof Cmd)
        {pair.send(received);}
      }
      System.out.println("Sup?");
    }
    catch(IOException|ClassNotFoundException e)
    {}
    finally
    {
      System.out.println("DISCONNECTED!");
      Server.disconnect(this);
      Server.disconnect(pair);
      
      try
      {pair.send(new Cmd("disconnected"));}
      catch(IOException e)
      {}
      
    }
  }
  
  void send(Object str) throws IOException
  {
    Sender sender=new Sender(socket);
    sender.send(str);
  }
  
  void terminate()
  {running=false;}

}
