package pkg;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;

public class Server 
{
  static ArrayList<ClientThread> clientsPending=new ArrayList<>();
  static ArrayList<ClientThread> clientsMatching=new ArrayList<>();
  
  public static void main(String[] args)
  {
    System.out.println("Waiting for clients.");
    try 
    {
      ServerSocket socketListener=new ServerSocket(1234);
      
      while(true)
      {
        //Waiting for new client.
        Socket client=null;
        while(client==null) 
        {client=socketListener.accept();}
        //Waiting for new client.
        
        //Opening new thread for client.
        ClientThread newClient=new ClientThread(client);
        newClient.start();
        clientsPending.add(newClient);
        //Opening new thread for client.
        
        //Pairing two pending clients.
        if (clientsPending.size()>1)
        {automatch();}
        //Pairing two pending clients.
      }
    }
    catch(SocketException e)
    {System.err.println("Socket exception");}
    catch (IOException e) 
    {System.err.println("I/O exception");}
  }
  
  private static void automatch()
  {
    ClientThread client1=clientsPending.remove(0),
                 client2=clientsPending.remove(0);
    

    //Pairing clients.
    client1.pair=client2;
    client2.pair=client1;
    //Pairing clients.
    
    clientsMatching.add(client1);
    clientsMatching.add(client2);
  }
  
  public static void disconnect(ClientThread client)
  {clientsMatching.remove(client);}
  
}
