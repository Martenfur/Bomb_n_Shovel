package pkg;

import java.io.Serializable;

/**
 *
 */
public class Cmd implements Serializable
{
  String command;
  double args[];
  
  public Cmd(String command_arg,double... args_arg)
  {
    command=command_arg;
    args=args_arg.clone();
  }
  
  /**
   * @return Command.
   */
  public String get()
  {return command;}
  
  /**
   * @param i Argument index.
   * @return Argument with given index.
   */
  public double get(int i)
  {return args[i];}
}
